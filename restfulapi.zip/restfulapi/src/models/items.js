const mongoose = require("mongoose");
const validator = require("validator");

const itemSchema = new mongoose.Schema({
    groceryItem : {
        type:String
        
    },
    
        isPurchased:{
            type:Boolean
            
        }
    
})

//we will create a new collection
const Item = new mongoose.model("Item",itemSchema);

module.exports = Item;