const express = require("express");
require("./db/conn");
const Item = require("./models/items");
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());
app.post("/grocery/add",async(req,res)=>{
    try {
          const item_1 = new Item({
             groceryItem:req.body.groceryItem,
              isPurchased:req.body.isPurchased
            });
            const Item1 = await item_1.save();
             res.status(201).json({"result":"success"});
          
    } catch (error) {
       console.log(error);
       res.status(500).send();
    }
 })

 app.get("/grocery/getAll",async(req,res)=>{
    try{
       const Itemdata = await Item.find();
       res.status(201).send(Itemdata);
    }catch (error) {
      console.log(error);
      res.status(500).send();
   }
 })

 app.put("/grocery/updatePurchaseStatus",async(req,res)=>{
   
      const id = req.body._id;
      try{
        const updateitem = await Item.findById(id)
        updateitem.isPurchased = req.body.isPurchased
        const data = await updateitem.save()
        res.status(201).json({"result":"success"});

   
 

   }catch(e){
      res.send(e);
   }
});

 
app.delete("/grocery/deleteGroceryItem",async(req,res)=>{
   
   const id = req.body._id;
   try{
     const updateitem = await Item.findByIdAndRemove(id)
     
     const data = await updateitem.save()
     res.status(201).send({"result":"success"});




}catch(e){
   res.send(e);
}
});




app.listen(port, () => {
    console.log(`connection is setup at ${port}`);
})



